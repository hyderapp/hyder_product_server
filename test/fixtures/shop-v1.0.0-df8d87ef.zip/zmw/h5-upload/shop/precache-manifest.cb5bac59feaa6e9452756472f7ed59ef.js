self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/ajax-loader.c5cd7f5300576ab4c88202b42f6ded62.gif"
  },
  {
    "revision": "9bd9c53e84dee130406e",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/app-9bd9c53e.js"
  },
  {
    "revision": "9bd9c53e84dee130406e",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/app-c2c3764c.css"
  },
  {
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/arc.f3e4539bed9d9c138b87672a84cf4434.png"
  },
  {
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/default_product.ef9211f1f6567eca5eaa13a8c16058f0.png"
  },
  {
    "revision": "f6d5db99ac3c8246198f",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/hlj-f6d5db99.chunk.js"
  },
  {
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/i_certify.f3e3f2723bb1422d516e8e1dd0db513a.gif"
  },
  {
    "revision": "ed93ce55f0ad0a1b7ae0986ca31bce14",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/index-c6f0c21c.html"
  },
  {
    "revision": "ed93ce55f0ad0a1b7ae0986ca31bce14",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/index.html"
  },
  {
    "revision": "ed93ce55f0ad0a1b7ae0986ca31bce14",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/list-c6f0c21c.html"
  },
  {
    "revision": "ed93ce55f0ad0a1b7ae0986ca31bce14",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/list.html"
  },
  {
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/loading.8cc74c2599d3a659dfd1bbf911b4af6e.gif"
  },
  {
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/logo.dc3a68967b78d09b4991e3307410db5c.png"
  },
  {
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/user_head.5f65114ca74ed07183751f04fa42087d.png"
  },
  {
    "revision": "9630a410a99c4b1eaeea",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/vendors-9630a410.chunk.js"
  },
  {
    "revision": "1844cbf3ab56456305e5d53b98048724",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/vendors-9630a410.chunk.js.LICENSE"
  }
]);