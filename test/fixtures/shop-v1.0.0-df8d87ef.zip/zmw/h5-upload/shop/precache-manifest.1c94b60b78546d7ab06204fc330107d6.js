self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "710037f12600cc5bcbad",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/service-710037f1.js"
  },
  {
    "revision": "19847f685df050190bf22db39bb44898",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/service-710037f1.js.LICENSE"
  },
  {
    "revision": "710037f12600cc5bcbad",
    "url": "https://static.helijia.cn/zmw/h5-upload/shop/service-e327a635.css"
  }
]);